<?php
    $dbserver = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'stc';
?>