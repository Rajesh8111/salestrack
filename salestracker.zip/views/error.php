<html lang="en">
    <head>
    <meta charset="utf-8">
    <title>Sales Tracker - Error from Webpage(</title>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <link rel="stylesheet" href="../assets/css/error.css">
    </head>
    

    <body>
    
    <div class="unicorn"></div>
            
    <div class="container">
      
        <div class="four-oh-four"><h1>404 Error</h1></div>
              
        <div class="warning">            
            <h2>"All those moments will be lost in time, like tears in rain."</h2>
            <a href="javascript:history.back()">Please go back to the previous page</a>
        </div>
       

    </div><!-- /.container -->                             

    <script src="../assets/js/error.js"></script>
    </body>
</html>

