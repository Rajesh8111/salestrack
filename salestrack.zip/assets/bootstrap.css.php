<link rel="stylesheet" href="../assets/css/bootstrap.min.css">
<link href="https://fonts.googleapis.com/css?family=Mina" rel="stylesheet">
<link href="../assets/css/general.css" rel="stylesheet">