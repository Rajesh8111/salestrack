<script src="../assets/js/jquery-3.2.1.min.js"></script>
<script src="../assets/js/popper.min.js"></script>
<script src="../assets/js/bootstrap.min.js"></script>


<!-- Auth Controller -->
<script src="../controller/Auth.js"></script>